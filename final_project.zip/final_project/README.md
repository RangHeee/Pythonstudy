# 다빈치 코드 게임
- 파이썬 스터디 final project

## Project 소개
- 0부터 9까지의 난수로 이루어진 4자리의 비밀 코드를 맞추는 게임

## Project 주요 내용

![Alt text](image.png)

![Alt text](image-1.png)